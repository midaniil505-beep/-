(() => {
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const W=900,H=500,gravity=.55,moveSpeed=3.5,jump=-10.8;
let level=1,apples=0,unlocked=1,player,platforms,hazards,apple,keys={},camera=0,won=false,dead=false,last=0,toastTimer;
const levelNum=document.getElementById('levelNum'),appleText=document.getElementById('apples'),progress=document.getElementById('progress'),grid=document.getElementById('levelGrid'),toast=document.getElementById('toast');
try{unlocked=Math.max(1,Math.min(70,Number(localStorage.getItem('snakeQuestUnlocked'))||1));apples=Number(localStorage.getItem('snakeQuestApples'))||0}catch(e){}
function makeLevel(n){const width=1450+Math.min(n*28,800),floorY=425;let p=[{x:0,y:floorY,w:210,h:75},{x:270,y:floorY-45-(n%3)*8,w:125,h:20},{x:455,y:floorY-100-(n%4)*7,w:130,h:20},{x:650,y:floorY-50,w:105,h:20},{x:820,y:floorY-125-(n%5)*5,w:140,h:20},{x:1040,y:floorY-75,w:115,h:20},{x:1240,y:floorY-130,w:190,h:20}];
if(n%2===0)p.splice(3,0,{x:565,y:floorY+5,w:35,h:20});
// More platforms and varied traps in later stages.
for(let i=0;i<Math.min(5,Math.floor((n-1)/12));i++){let x=350+i*220;p.push({x:x+35,y:300-(i%3)*35,w:75,h:16})}
let h=[];for(let i=0;i<Math.min(2+Math.floor(n/10),7);i++){let x=190+i*(width-330)/Math.min(2+Math.floor(n/10),7);if(x>230&&x<width-100)h.push({x,y:floorY-15,w:26+(n%3)*5,h:15})}
return {width,platforms:p,hazards:h,apple:{x:width-80,y:floorY-175-(n%4)*10,w:28,h:30}}}
function startLevel(n){level=Math.max(1,Math.min(unlocked,n));let l=makeLevel(level);platforms=l.platforms;hazards=l.hazards;apple=l.apple;player={x:35,y:365,w:32,h:40,vx:0,vy:0,onGround:false,face:1};camera=0;won=false;dead=false;toast.classList.add('hidden');updateHUD();renderGrid()}
function updateHUD(){levelNum.textContent=String(level).padStart(2,'0')+' / 70';appleText.textContent=apples+' 🍎';progress.textContent=unlocked+' / 70'}
function renderGrid(){grid.innerHTML='';for(let i=1;i<=70;i++){let b=document.createElement('button');b.textContent=i;b.className=(i<unlocked?'done ':'')+(i===level?'current':'');b.title=i<=unlocked?'Уровень '+i:'Сначала пройди предыдущие уровни';b.disabled=i>unlocked;b.onclick=()=>startLevel(i);grid.appendChild(b)}}
function showToast(title,subtitle,button,action){toast.innerHTML=`<div>${title}</div><small>${subtitle}</small><button id="toastAction">${button}</button>`;toast.classList.remove('hidden');document.getElementById('toastAction').onclick=action}
function die(){if(dead||won)return;dead=true;showToast('Ой! 🐍','Попробуй ещё раз — шипы опасны.','Повторить уровень',()=>startLevel(level))}
function win(){if(won)return;won=true;apples++;if(level===unlocked&&unlocked<70)unlocked++;try{localStorage.setItem('snakeQuestUnlocked',unlocked);localStorage.setItem('snakeQuestApples',apples)}catch(e){}updateHUD();renderGrid();if(level===70)showToast('Ты победил! 🏆','Все 70 уровней пройдены!','Играть снова',()=>startLevel(1));else showToast('Уровень пройден! 🍎','Отличная работа! Открыт уровень '+(level+1),'Следующий уровень →',()=>startLevel(level+1))}
function overlaps(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y}
function update(){if(won||dead)return;player.vx=0;if(keys.ArrowLeft||keys.KeyA){player.vx=-moveSpeed;player.face=-1}if(keys.ArrowRight||keys.KeyD){player.vx=moveSpeed;player.face=1}if((keys.ArrowUp||keys.Space||keys.KeyW)&&player.onGround){player.vy=jump;player.onGround=false}player.x+=player.vx;player.x=Math.max(0,Math.min(player.x,makeLevel(level).width-player.w));player.vy+=gravity;player.y+=player.vy;player.onGround=false;
for(const p of platforms){if(player.vy>=0&&player.x+player.w>p.x&&player.x<p.x+p.w&&player.y+player.h>=p.y&&player.y+player.h-player.vy<=p.y){player.y=p.y-player.h;player.vy=0;player.onGround=true}}
if(player.y>H+80)die();for(const h of hazards)if(overlaps(player,{x:h.x,y:h.y-6,w:h.w,h:h.h+10}))die();if(overlaps(player,apple))win();camera=Math.max(0,Math.min(player.x-W*.32,makeLevel(level).width-W))}
function roundRect(x,y,w,h,r,fill){ctx.fillStyle=fill;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill()}
function draw(){ctx.clearRect(0,0,W,H);let bg=ctx.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#132b43');bg.addColorStop(1,'#0b1525');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);ctx.save();ctx.translate(-camera,0);
// Subtle retro grid and stars
ctx.strokeStyle='#20364a';ctx.lineWidth=1;for(let x=Math.floor(camera/40)*40;x<camera+W;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}for(let y=25;y<H;y+=40){ctx.beginPath();ctx.moveTo(camera,y);ctx.lineTo(camera+W,y);ctx.stroke()}
for(const p of platforms){roundRect(p.x,p.y,p.w,p.h,5,'#34516a');roundRect(p.x,p.y,p.w,5,3,'#b8f34a')}
for(const h of hazards){ctx.fillStyle='#ff637d';ctx.beginPath();ctx.moveTo(h.x,h.y+h.h);ctx.lineTo(h.x+h.w/2,h.y-7);ctx.lineTo(h.x+h.w,h.y+h.h);ctx.closePath();ctx.fill()}
// apple
ctx.font='31px system-ui';ctx.fillText('🍎',apple.x-2,apple.y+29);ctx.strokeStyle='#b8f34a';ctx.setLineDash([5,5]);ctx.strokeRect(apple.x-8,apple.y-8,apple.w+16,apple.h+14);ctx.setLineDash([]);
// snake body with pixel-style segments
roundRect(player.x,player.y+9,player.w,player.h-9,9,'#8fda39');roundRect(player.x+4,player.y+14,player.w-8,player.h-18,6,'#b8f34a');ctx.fillStyle='#203017';let ex=player.face===1?player.x+23:player.x+7;ctx.beginPath();ctx.arc(ex,player.y+15,3,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.arc(ex,player.y+25,3,0,Math.PI*2);ctx.fill();ctx.restore();
// progress strip
ctx.fillStyle='#24384c';ctx.fillRect(0,H-5,W,5);ctx.fillStyle='#b8f34a';ctx.fillRect(0,H-5,W*(level/70),5);
}
function loop(t){if(t-last>15){update();draw();last=t}requestAnimationFrame(loop)}
window.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space'].includes(e.code))e.preventDefault();keys[e.code]=true;if((e.code==='KeyR')&&!won&&!dead)startLevel(level)});window.addEventListener('keyup',e=>keys[e.code]=false);window.addEventListener('blur',()=>keys={});document.querySelectorAll('[data-key]').forEach(b=>{const k=b.dataset.key;b.addEventListener('pointerdown',e=>{e.preventDefault();keys[k]=true;if(k==='ArrowUp'&&player.onGround){player.vy=jump;player.onGround=false}});for(const ev of ['pointerup','pointercancel','pointerleave'])b.addEventListener(ev,()=>keys[k]=false)});document.getElementById('restart').onclick=()=>startLevel(level);
startLevel(1);requestAnimationFrame(loop);
})();
